﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace B4.PE1.HuygheK
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Picture : ContentPage
	{
		public Picture ()
		{
			InitializeComponent ();
		}
	}
}